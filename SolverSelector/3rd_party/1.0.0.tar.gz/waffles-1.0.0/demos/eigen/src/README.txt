
This demo is just a proof-of-concept to show that Waffles can play with the Eigen library.

To build it:
	(1) sudo apt-get install libeigen3-dev
	(2) make opt

